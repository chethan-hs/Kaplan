'use strict';

module.exports = function (app) {
  var assignmentController = require('../controllers/AssignmentController');


 /**
 * @api {post} /assignment Create Assignment
 * @apiName CreateAssignment
 * @apiGroup Assignment
 *
 * @apiParam {String} Name  Name of the Assignment.
 * @apiParam {String} Title Title of the Assignment.
 * @apiParam {String} Description  Description of the Assignment.
 * @apiParam {String} Type Type of the Assignment.
 * @apiParam {String} Duration  Duration of the Assignment.
 * @apiParam {String} Tags  Tags of the Assignment.
 */
  app.route('/assignment')
    .post(assignmentController.createAssignment);


/**
 * @api {get} /assignment/:ID  Request Assignment information
 * @apiName GetAssignment
 * @apiGroup Assignment
 *
 * @apiParam {String} ID Assignment unique ID.
 *
 * @apiSuccess {String} ID ID of the Assignment.
 * @apiSuccess {String} Name  Name of the Assignment.
 * @apiSuccess {String} Title Title of the Assignment.
 * @apiSuccess {String} Description  Description of the Assignment.
 * @apiSuccess {String} Type Type of the Assignment.
 * @apiSuccess {String} Duration  Duration of the Assignment.
 * @apiSuccess {String} Tags  Tags of the Assignment.
 */
  app.route('/assignment/:ID')
    .get(assignmentController.readAssignment);

  
 /**
 * @api {put} /assignment/:ID Update Assignment
 * @apiName updateAssignment
 * @apiGroup Assignment
 *
 * @apiParam {String} ID  ID of the Assignment. * 
 * @apiParam {String} Title Title of the Assignment.
 * @apiParam {String} Description  Description of the Assignment.
 * @apiParam {String} Type Type of the Assignment.
 * @apiParam {String} Duration  Duration of the Assignment.
 * @apiParam {String} Tags  Tags of the Assignment.
 */
  app.route('/assignment/:ID')
      .put(assignmentController.updateAssignment);


/**
 * @api {get} /assignment/Name/:Name Request Assignment information
 * @apiName GetAssignmentByName
 * @apiGroup Assignment
 *
 * @apiParam {String} Name  Name of the Assignment
 *
 * @apiSuccess {String} ID ID of the Assignment.
 * @apiSuccess {String} Name  Name of the Assignment.
 * @apiSuccess {String} Title Title of the Assignment.
 * @apiSuccess {String} Description  Description of the Assignment.
 * @apiSuccess {String} Type Type of the Assignment.
 * @apiSuccess {Number} Duration  Duration of the Assignment.
 * @apiSuccess {String} Tags  Tags of the Assignment.
 */
  app.route('/assignment/Name/:Name')
    .get(assignmentController.readAssignmentByName);
}