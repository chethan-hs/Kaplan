'use strict';
const HttpStatus = require('http-status-codes');
var assignmentDataProvider = require('../dataprovider/AssignmentDataProvider');
var uuid_validater = require('uuid-validate');



exports.readAssignment = function (req, res) {
  console.log("Requested Id to get the record=", req.params.ID);
  assignmentDataProvider.getAssignmentById(req.params.ID, function (result) {
      res.setHeader('Content-Type', 'application/json')
      res.status(result.error_code).end(JSON.stringify(result, null, 2)) 
    }
  );
};


exports.readAssignmentByName = function (req, res) {
  console.log("Requested assignment Name to get the record=", req.params.Name);
  assignmentDataProvider.getAssignmentByName(req.params.Name,
    function (result) {
      res.setHeader('Content-Type', 'application/json')
      res.status(result.error_code).end(JSON.stringify(result, null, 2)) 
    }
  );
};


exports.updateAssignment = function (req, res) {
  var ID = req.params.ID;  
  if(uuid_validater(ID , 4) == false){
    var result = new Object();
    result.status = "error";   
    result.message = "Invalid Assignment ID:"+ ID;
    result.error_code = HttpStatus.BAD_REQUEST;
    res.setHeader('Content-Type', 'application/json')
    res.status(result.error_code).end(JSON.stringify(result, null, 2)) 
  }else{
    if(isValidAssignment(req, res)) {
      assignmentDataProvider.updateOrCreateAssignment(ID, req.body.Assignment,
        function (result) {
          res.setHeader('Content-Type', 'application/json')
          res.status(result.error_code).end(JSON.stringify(result, null, 2)) 
        }
      );
    }
   }   
};


function isValidAssignment(req, res) {
  const assignment = req.body.Assignment;
  var validationResult = new Object();
  res.setHeader('Content-Type', 'application/json')

  if (typeof assignment == 'undefined') {
    validationResult.status = "error";
    validationResult.messages = "Invalid Assignment input";
    validationResult.data = null;
    validationResult.error_code = HttpStatus.BAD_REQUEST;
    res.status(HttpStatus.BAD_REQUEST).end(JSON.stringify(validationResult, null, 2))
    return false;
  }

  var message = []  
  const name = assignment.Name;
  if (typeof name == 'undefined' || name == null) {
    message.push('Field: Name cannot be null')
  } else {
    var specialChars = "~`!#$%^&*+=[]\\\';,/{}|\":<>?";
    for (var i = 0; i < name.length; i++) {
      if (name.charAt(i) == ' ' || specialChars.indexOf(name.charAt(i)) != -1) {
        message.push("Field: Name has special characters. space and special characters( ~`!#$%^&*+=-[]\\\';,/{}|\":<>?) are not allowed");
        break;
      }
    }
  }

  const type = assignment.Type;
  if (typeof type == 'undefined' || type == null) {
    message.push('Field: Type cannot be null.')
  } else {
    const validTypes = ['Prestitched', 'Adaptive', 'Random']
    if (validTypes.indexOf(type) != 1) {
      message.push('Field: Type value is invalid. Allowed values are (Prestitched,Adaptive and Random)')
    }
  }

  const duration = assignment.Duration;
  if (typeof duration == 'undefined' || duration == null) {
    message.push('Field: Duration cannot be null')
  } else {
    try {
      var val = parseInt(duration)
      if (val <= 0) {
        message.push('Field: Duration value should be greater than 0')
      }
    } catch (error) {
      console.log(error);
      message.push('Field: Duration value is invalid')
    }
  }

  if (message.length > 0) {
    validationResult.status = "error";
    validationResult.message = message;
    validationResult.data = null;
    validationResult.error_code = HttpStatus.BAD_REQUEST;
    res.status(HttpStatus.BAD_REQUEST).end(JSON.stringify(validationResult, null, 2))
    return false;
  }
  return true;
}


exports.createAssignment = function (req, res) {
  var result = new Object();
  if (isValidAssignment(req, res)) {
    var assignment = req.body.Assignment;
    assignmentDataProvider.createAssignment(assignment, function (result) {
      res.status(result.error_code).end(JSON.stringify(result, null, 2))
    }
    )
  }
}; 