const sqlite3 = require('sqlite3').verbose();
const uuidv4 = require('uuid/v4')
var fs = require('fs');
const HttpStatus = require('http-status-codes');


var CREATE_ASSIGNMENT_TABLE_SQL = 'CREATE TABLE IF NOT EXISTS ASSIGNMENT (ID TEXT PRIMARY KEY,  NAME TEXT NOT NULL UNIQUE,' +
    ' TITLE TEXT ,DESCRIPTION TEXT, TYPE TEXT, DURATION INTEGER)'
var CREATE_TAGS_TABLE_SQL = 'CREATE TABLE IF NOT EXISTS TAG( ASSIGNMENT_ID  TEXT, NAME TEXT)'

var INSERT_ASSIGNMENT_SQL = 'INSERT INTO ASSIGNMENT (ID, NAME, TITLE, DESCRIPTION, TYPE, DURATION)' +
    ' VALUES(?, ?, ?, ?, ?, ?)';
var SELECT_ALL_ASSIGNMENT_SQL = 'SELECT * FROM  ASSIGNMENT';
var SELECT_ASSIGNMENT_BY_ID_SQL = "SELECT * FROM  ASSIGNMENT WHERE ID = ?";
var SELECT_ASSIGNMENT_BY_NAME_SQL = "SELECT * FROM  ASSIGNMENT WHERE NAME = ?";

var INSERT_TAG_SQL = 'INSERT INTO TAG (ASSIGNMENT_ID, NAME) VALUES(?, ?)';
var SELECT_TAG_BY_ASSIGNMENT_ID_SQL = "SELECT * FROM  TAG WHERE ASSIGNMENT_ID = ?";
var SELECT_TAG_BY_NAME_SQL = "SELECT * FROM  TAG WHERE NAME = ?";

var sqlite3_DB = null;
var dbfile = 'data.db';


async function openDBConnection() {
    var result = new Object();
    sqlite3_DB = new sqlite3.Database(dbfile, (err) => {
        if (err) {
            return console.error(err.message);
        }
        console.log('Connected to the in-memory SQlite database.');
    });
    return result;
}


async function closeDBConnection() {
    var result = new Object();
    sqlite3_DB.close((err) => {
        if (err) {
            return console.error(err.message);
        }
        console.log('Close the database connection.');
    });
    return result;
}


exports.createTable = function () {
    console.log("Assignementdataprovider");

    //dropAssignmentTable();
    var exists = fs.existsSync(dbfile);
    if (!exists) {
        console.log("Creating DB file.");
        fs.openSync(dbfile, 'w');

        console.log("Creating Table ASSIGNMENT ....")
        openDBConnection();

        sqlite3_DB.run(CREATE_ASSIGNMENT_TABLE_SQL, function (err) {
            if (err) {
                return console.log(err.message);
            }
            console.log("ASSIGNMENT table created....")
        });

        console.log("Creating Table TAG ....")
        sqlite3_DB.run(CREATE_TAGS_TABLE_SQL, function (err) {
            if (err) {
                return console.log(err.message);
            }
            console.log("TAG table created....")
        });

        closeDBConnection();
    }
}


exports.createAssignment = function (assigement, setResponseCallback) {
    var result = new Object();
    openDBConnection()
        //.then(insertAssignement(assigement, result, setResponseCallback))       
        .then(checkAssignmentExistAndInsert(assigement, result, setResponseCallback))
        .then(closeDBConnection())
        .catch(err => function () {
            alert("Error = " + err.toString())
            result.message = err.toString();
            setResponseCallback(result);
        }
        )
}


function checkAssignmentExistAndInsert(assigement, result, setResponseCallback) {
    sqlite3_DB.get(SELECT_ASSIGNMENT_BY_NAME_SQL, [assigement.Name], function (err, row) {
        if (err) {
            console.log(err.message);
            result.status = "error";
            result.message = "Internal server exception.";
            result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
            setResponseCallback(result);
        } else {
            if (typeof row !== 'undefined') {
                result.status = "error";
                result.message = "Assignment with name: " + assigement.Name + " already exist";
                result.error_code = HttpStatus.CONFLICT;
                setResponseCallback(result);
            } else {
                insertAssignement(null, assigement, result, setResponseCallback)
            }
        }
    });
}



function insertAssignement(uuid4, assigement, result, setResponseCallback) {
    if (uuid4 == null)
        uuid4 = uuidv4()
    sqlite3_DB.run(INSERT_ASSIGNMENT_SQL, [uuid4, assigement.Name, assigement.Title, assigement.Description, assigement.Type,
        assigement.Duration], function (err) {
            if (err) {
                console.log(err.message);
                result.status = "error";
                result.message = "Exception occured while creating Assignment.";
                result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
                setResponseCallback(result);
            } else {
                console.log("Assignment created with Id:" + uuid4);
                assigement.ID = uuid4;
                insertTag(assigement.ID, assigement.Tags, result, setResponseCallback);
            }
        });
}


function insertTag(assignmentID, Tags, result, setResponseCallback) {
    if (typeof Tags == 'undefined')
        return;

    var isErrorOccured = false;
    for (var i = 0; i < Tags.length; i++) {
        sqlite3_DB.run(INSERT_TAG_SQL, [assignmentID, Tags[i]], function (err) {
            if (err) {
                console.log("error=", err);
                result.status = "error";
                result.message = "Exception occured while creating Tag."
                result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
                isErrorOccured = true;
            } else {
                console.log(Tags[i] + " Tag is created.");
            }
        });

        if (isErrorOccured == false) {
            result.status = "success";
            result.message = "Assignment created with Id:" + assignmentID;
            result.error_code = HttpStatus.OK;
        }
        setResponseCallback(result);
    }
}






exports.getAssignmentById = function (ID, setResponseCallback) {
    var result = new Object();
    var data = new Object();
    result.data = data;
    var params = [ID]
    openDBConnection()
        .then(getAssignmentById(sqlite3_DB, params, result, setResponseCallback))
        .then(closeDBConnection())
        .catch(err => function () {
            alert("Error = " + err.toString())
            result.message = err.toString();
            setResponseCallback(result);
        }
        )
}

function getAssignmentById(sqlite3_DB, params, result, setResponseCallback) {
    sqlite3_DB.get(SELECT_ASSIGNMENT_BY_ID_SQL, params, function (err, row) {
        if (err) {
            console.log(err.message);
            result.status = "error";
            result.message = "Internal server error"
            result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
            setResponseCallback(result);
        } else {
            if (typeof row != 'undefined') {
                result.data.assignment = createAssignmentObject(row);
                getTags(sqlite3_DB, SELECT_TAG_BY_ASSIGNMENT_ID_SQL, params, result, setResponseCallback)
            } else {
                result.status = "error";
                result.message = "Invalid assignment ID:" + params[0]
                result.error_code = HttpStatus.BAD_REQUEST;
                setResponseCallback(result);
            }
        }
    });
}


function createAssignmentObject(row) {
    var assignment = new Object();
    assignment.ID = row.ID;
    assignment.Name = row.NAME;
    assignment.Title = row.TITLE;
    assignment.Description = row.DESCRIPTION;
    assignment.Type = row.TYPE;
    assignment.Duration = row.DURATION;
    return assignment;
}

function getTags(sqlite3_DB, SQL, params, result, setResponseCallback) {
    sqlite3_DB.all(SQL, params, function (err, rows) {
        if (err) {
            console.log("Exception occured while fetching tags.");
            console.log(err.message);
            result.message = "Internal server error"
            result.status = "error";
            result.data.assignment = null;
            result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;;

        } else {
            var Tags = [rows.length];
            var index = 0;
            rows.forEach((row) => {
                if (err) {
                    console.log("Error", err);
                } else {
                    Tags[index++] = row.NAME;
                    //console.log("assignments=", JSON.stringify(assignments));                                     
                }
            });
            result.data.assignment.Tags = Tags;
            result.status = "success";
            result.error_code = HttpStatus.OK;

        }
        setResponseCallback(result);
    });
}





exports.getAssignmentByName = function (NAME, setResponseCallback) {
    var result = new Object();
    var data = new Object();
    result.data = data;

    var params = [NAME]
    openDBConnection()
        .then(getAssignmentByName(sqlite3_DB, params, result, setResponseCallback))
        .then(closeDBConnection())
        .catch(err => function () {
            alert("Error = " + err.toString())
            result.message = err.toString();
            setResponseCallback(result);
        }
        )
}

function getAssignmentByName(sqlite3_DB, params, result, setResponseCallback) {
    sqlite3_DB.get(SELECT_ASSIGNMENT_BY_NAME_SQL, params, function (err, row) {
        if (err) {
            console.log(err.message);
            result.status = "error";
            result.message = "Internal server error"
            result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
            setResponseCallback(result);
        } else {
            if (typeof row !== 'undefined') {
                result.data.assignment = createAssignmentObject(row);
                getTags(sqlite3_DB, SELECT_TAG_BY_ASSIGNMENT_ID_SQL, [result.data.assignment.ID], result, setResponseCallback);
            } else {
                result.status = "error";
                result.message = "Invalid Assignment name:" + params[0];
                result.error_code = HttpStatus.BAD_REQUEST;
                setResponseCallback(result);
            }
        }
    });
}



exports.updateOrCreateAssignment = function (ID, assigement, setResponseCallback) {
    var result = new Object();
    openDBConnection()
        .then(checkAndUpdateOrCreateAssignment(sqlite3_DB, ID, result, assigement, setResponseCallback))
        .then(closeDBConnection())
        .catch(err => function () {
            alert("Error = " + err.toString())
            result.message = err.toString();
            setResponseCallback(result);
        }
        )
}




function checkAndUpdateOrCreateAssignment(sqlite3_DB, ID, result, assigement, setResponseCallback) {

    sqlite3_DB.get(SELECT_ASSIGNMENT_BY_ID_SQL, [ID], function (err, row) {
        if (err) {
            console.log(err.message);
            result.status = "error";
            result.message = "Internal server error"
            result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
            setResponseCallback(result);
        } else {
            if (typeof row != 'undefined') {
                var UPDATE_ASSIGNMENT_SQL = 'UPDATE ASSIGNMENT SET '
                var params = []
                var isFirstField = true;

                if (typeof assigement.Title !== 'undefined') {
                    UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ' TITLE=?'
                    params.push(assigement.Title);
                    isFirstField = false
                }
                if (typeof assigement.Description !== 'undefined') {
                    if (isFirstField == true){
                        UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ' DESCRIPTION=?'
                        isFirstField = false
                    }
                    else
                        UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ', DESCRIPTION=?'

                    params.push(assigement.Description);
                }

                if (typeof assigement.Type !== 'undefined') {
                    if (isFirstField == true){
                        UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ' TYPE=?'
                        isFirstField = false
                    }
                    else
                        UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ', TYPE=?'
                    params.push(assigement.Type);
                }

                if (typeof assigement.Duration !== 'undefined') {
                    if (isFirstField == true){
                        UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ' DURATION=?'
                        isFirstField = false
                    }
                    else
                        UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ', DURATION=?'
                    params.push(assigement.Duration);
                }
                UPDATE_ASSIGNMENT_SQL = UPDATE_ASSIGNMENT_SQL + ' WHERE ID = ?';
                params.push(ID);

                console.log(UPDATE_ASSIGNMENT_SQL);
                console.log(params);
                sqlite3_DB.run(UPDATE_ASSIGNMENT_SQL, params, function (err) {
                    if (err) {
                        console.log("Exception while deleting tag",err.message);
                        result.status = "error";
                        result.message = "Exception occured while updating assignment";
                        result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
                        setResponseCallback(result);
                    } else {

                       DELETE_TAG_SQL = "DELETE FROM TAG WHERE ASSIGNMENT_ID =\'" + ID +"\'";
                      // console.log(DELETE_TAG_SQL)
                        sqlite3_DB.run(DELETE_TAG_SQL, function (err) {
                            if (err) {
                                console.log("Exception while deleting tag.",err.message);
                                result.status = "error";
                                result.message = "Exception occured while updating Tags";
                                result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
                               // setResponseCallback(result);
                            }
                            else{
                                if (typeof assigement.Tags !== 'undefined') {
                                    var isErrorOccured = false;
                                    for (var i = 0; i < assigement.Tags.length; i++) {
                                        sqlite3_DB.run(INSERT_TAG_SQL, [ID, assigement.Tags[i]], function (err) {
                                            if (err) {
                                                console.log("error=", err);
                                                result.status = "error";
                                                result.message = "Exception occured while updating Tag."
                                                result.error_code = HttpStatus.INTERNAL_SERVER_ERROR;
                                                isErrorOccured = true;
                                            } else {
                                               // console.log(assigement.Tags[i] + " Tag is created.");
                                            }
                                        });
                                    }
                                    if (isErrorOccured == false) {
                                        result.status = "success";
                                        result.message = "Assignment updated with Id:" + ID;
                                        result.error_code = HttpStatus.OK;
                                    }
                                    setResponseCallback(result);
                                }
                            }
                        }); 

                    }
                });

            } else {
                insertAssignement(uuid4, assigement, result, setResponseCallback)
            }
        }
    });

}



